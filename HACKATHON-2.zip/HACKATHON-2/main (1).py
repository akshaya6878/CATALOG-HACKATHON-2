import random

class SmartAssessmentBoard:
    def __init__(self):
        # List of tuples containing states, their capitals, and a hint phrase
        self.questions = [
            ("Andhra Pradesh", "Amaravati", "The upcoming capital known for the Amaravati Stupa."),
            ("Arunachal Pradesh", "Itanagar", "The capital shares its name with a famous Itanagar Fort."),
            ("Assam", "Dispur", "The smallest capital city in the world."),
            ("Bihar", "Patna", "The city where Mahatma Gandhi launched the Champaran movement."),
            ("Chhattisgarh", "Raipur", "Known for its steel markets."),
            ("Goa", "Panaji", "A popular tourist destination, known for its beaches."),
            ("Gujarat", "Gandhinagar", "Named after the Father of the Nation, Mahatma Gandhi."),
            ("Haryana", "Chandigarh", "This city is also the capital of Punjab."),
            ("Himachal Pradesh", "Shimla", "A famous hill station and former summer capital of British India."),
            ("Jharkhand", "Ranchi", "Known as the city of waterfalls."),
            ("Karnataka", "Bengaluru", "Known as the Silicon Valley of India."),
            ("Kerala", "Thiruvananthapuram", "Named after Lord Vishnu, also known as the Evergreen City of India."),
            ("Madhya Pradesh", "Bhopal", "Known for its lakes."),
            ("Maharashtra", "Mumbai", "The financial capital of India, also known as the City of Dreams."),
            ("Manipur", "Imphal", "Famous for its scenic landscapes and Loktak Lake."),
            ("Meghalaya", "Shillong", "Often referred to as the Scotland of the East."),
            ("Mizoram", "Aizawl", "Known for its picturesque views of the surrounding valley."),
            ("Nagaland", "Kohima", "Known for the Hornbill Festival."),
            ("Odisha", "Bhubaneswar", "The city of temples."),
            ("Punjab", "Chandigarh", "This city is also the capital of Haryana."),
            ("Rajasthan", "Jaipur", "The Pink City."),
            ("Sikkim", "Gangtok", "Known for its stunning views of Kanchenjunga."),
            ("Tamil Nadu", "Chennai", "Known for its Marina Beach."),
            ("Telangana", "Hyderabad", "The city of pearls."),
            ("Tripura", "Agartala", "Famous for the Ujjayanta Palace."),
            ("Uttar Pradesh", "Lucknow", "Known as the City of Nawabs."),
            ("Uttarakhand", "Dehradun", "Known for its prestigious schools."),
            ("West Bengal", "Kolkata", "The City of Joy.")
        ]
        self.score = 0
        self.student_name = ""
        self.incorrect_answers = []
        self.skipped_questions = 0
        self.attempted_questions = 0  # Track whether any questions were attempted

    def get_user_input(self, prompt):
        user_input = input(prompt + " (Enter 'q' to quit, 's' to skip, or 'h' for a hint): ").strip()
        return user_input

    def grade_quiz(self, score, total):
        percentage = (score / total) * 100
        if percentage >= 90:
            return "A"
        elif percentage >= 80:
            return "B"
        elif percentage >= 70:
            return "C"
        elif percentage >= 60:
            return "D"
        else:
            return "F"

    def display_results(self):
        total_questions = len(self.questions)
        correct_answers = self.score
        skipped_questions = self.skipped_questions
        incorrect_answers = len(self.incorrect_answers)
        grade = self.grade_quiz(correct_answers, total_questions)

        remarks = {
            "A": "Excellent work!",
            "B": "Good job!",
            "C": "Fair effort!",
            "D": "Needs improvement.",
            "F": "Better luck next time."
        }

        if self.attempted_questions == 0:
            print("\nYou haven't answered any questions.")
        else:
            print("\nQuiz Completed!")
            print(f"Student Name: {self.student_name}")
            print(f"Total Questions: {total_questions}")
            print(f"Correct Answers: {correct_answers}")
            print(f"Skipped Questions: {skipped_questions}")
            print(f"Incorrect Answers: {incorrect_answers}")
            print(f"Your grade is: {grade}")
            print(f"Remarks: {remarks[grade]}")

        if self.incorrect_answers:
            self.review_incorrect_answers()

    def review_incorrect_answers(self):
        if not self.incorrect_answers:
            print("\nCongratulations! You got all the answers correct.")
            return

        print("\nReview your incorrect answers:")
        for state, correct_answer, user_answer in self.incorrect_answers:
            print(f"The capital of {state} is {correct_answer}, not {user_answer}.")

    def generate_options(self, correct_answer):
        options = [correct_answer]
        while len(options) < 4:
            wrong_answer = random.choice([capital for _, capital, _ in self.questions])
            if wrong_answer not in options:
                options.append(wrong_answer)
        random.shuffle(options)
        return options

    def start_quiz(self):
        print("Welcome to the States and Capitals Quiz Competition!")
        
        # Input student name
        self.student_name = input("Please enter the student's name: ").strip()
        print(f"\nHello, {self.student_name}! Let's start the quiz.")

        # Select difficulty level
        difficulty = input("\nChoose your difficulty level (Easy, Medium, Hard): ").strip().lower()
        if difficulty == 'easy':
            num_questions = 5
        elif difficulty == 'medium':
            num_questions = 15
        else:
            num_questions = len(self.questions)

        print(f"\nIdentify the correct capital for the given state.\n")

        # Randomize and limit the number of questions
        random.shuffle(self.questions)
        selected_questions = self.questions[:num_questions]

        for state, capital, hint in selected_questions:
            options = self.generate_options(capital)
            print(f"What is the capital of {state}?")
            for idx, option in enumerate(options):
                print(f"{idx + 1}. {option}")

            user_answer = self.get_user_input("Choose the correct option (1/2/3/4)")

            if user_answer.lower() == 'q':
                print("Exiting the quiz...")
                break

            if user_answer.lower() == 's':
                print(f"Skipped! The correct answer was {capital}.")
                self.skipped_questions += 1
                continue  # Move to the next question without ending the quiz

            if user_answer.lower() == 'h':
                print(f"Hint: {hint}")
                user_answer = input("Your answer: ").strip()

            try:
                if options[int(user_answer) - 1].lower() == capital.lower():
                    print("Correct!")
                    self.score += 1
                    self.attempted_questions += 1
                else:
                    print(f"Wrong! The correct answer is {capital}.")
                    self.incorrect_answers.append((state, capital, options[int(user_answer) - 1]))
                    self.attempted_questions += 1
            except (IndexError, ValueError):
                print("Invalid input. Please enter a number between 1 and 4.")

        self.display_results()
        self.update_leaderboard()

    def update_leaderboard(self):
        try:
            with open("leaderboard.txt", "a") as f:
                f.write(f"{self.student_name}: {self.score}\n")
        except IOError:
            print("Error writing to leaderboard file.")

if __name__ == "__main__":
    quiz = SmartAssessmentBoard()
    quiz.start_quiz()
